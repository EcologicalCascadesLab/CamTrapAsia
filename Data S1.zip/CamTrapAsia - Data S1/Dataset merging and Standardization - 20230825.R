### Calebe Pereira Mendes
### 03-04-2023

rm(list = ls())


### packages
require(tidyverse)
require(taxize)




### Load the raw data.
#The raw data contain the records compiled from the original data authors + covariates extracted by the dataset originators (CPM)

metadata  = read.csv("metadata_raw_20230825.csv")
captures  = read.csv("captures_raw_20230825.csv")



### Bring the geographical information from the Metadata  to to Captures

geo = metadata %>% 
  select("survey_id","Y_lat","X_long","year_start","country")

captures = captures %>% 
  left_join(geo, by = "survey_id")

rm(geo)




### Inspect the species naming

sort(unique(captures$genus_species))


#Standardize the spaces  and remove "sp.", "spp", etc.
captures$genus_species = captures$genus_species %>%  
  str_replace_all(c("\xa0" = " ",
                    "_" = " ",
                    " sp." = "",
                    " sp" = "",
                    " spp" = ""))



# delete invalid entries or records not identified at least to order
delete = c("Xerus princeps? prob.wrong","Vehicle","Scorpion",
           "Small mammal","Reptile","Mammalia","frog","bird",
           "bat bird?","Insect","raptor","tailless bandicoot?",
           "cuscus?","Viverridae or Prionodontidae","Domestic livestock",
           "Lizard","Rodent or marsupial","Butterfly",'NOT Atherurus macrourus')

captures = captures[!captures$genus_species %in% delete,]
rm(delete)



#Change some records for more scientific terms.
captures$genus_species[captures$genus_species == "bat"] = "Chiroptera"
captures$genus_species[captures$genus_species == "Rodent"] = "Rodentia"
captures$genus_species[captures$genus_species == "Snake"] = "Serpentes"


# Mark domestic records in a new column and remove "Domestic" from the records
captures$domestic = "wild"
captures$domestic[str_detect(captures$genus_species, "Domestic")] = "domestic"

captures$genus_species = captures$genus_species %>%  
  str_replace_all(c("Domestic " = "", " Domestic" = ""))





### Standardize the scientific names using Taxize


# Make a species list for standardization
species_list = sort(unique(captures$genus_species))


#search in NCBI
NCBI_uids <- get_ids(species_list, db = 'ncbi', verbose = F) #Stay alert! The function sometimes ask for confirmations! (and sometimes it fails...)
NCBI <- classification(NCBI_uids)

#Which species were not found?
missing = attr(NCBI_uids$ncbi, "names")[attr(NCBI_uids$ncbi, "match") != "found"] 

#search the missing ones in GBIF
GBIF_uids <- get_ids(missing, db = 'gbif', verbose = F) #Stay alert! The function sometimes ask for confirmations! (and sometimes it fails...)
GBIF <- classification(GBIF_uids)

#Are there any species still missing?
missing = attr(GBIF_uids$gbif, "names")[attr(GBIF_uids$gbif, "match") != "found"] 
if(length(missing) == 0){rm(missing, species_list)}


#save.image("save.Rdata")
#load("save.Rdata")


### Create a function to facilitate accessing the classification info

extract.classif = function(uids = NULL, classif = NULL, request = c("species","genus","family","order","class")){
  
  require(tidyverse)
  require(taxize)
  
  #warnings
  if(is.null(uids)){ print("Missing argument 1: IDs. Use taxize::get_ids() to obtain the ids"); break }
  if(is.null(classif)){ print("Missing argument 2: Classification. Use taxize::classification() to obtain the classification"); break }
  
  #make a table
  sp = data.frame(user_provided_name = attr(uids[[1]],"names")) %>% 
    cbind(data.frame(uids[[1]])) %>% 
    select(-"class")
  
  t = data.frame(matrix(NA,nrow = nrow(sp),ncol = length(request)))
  colnames(t) = request
  sp = cbind(sp,t)
  rm(t)
  
  #remove NAs
  sp = sp[!is.na(sp$ids),] 
  classif[[1]] =  classif[[1]][!is.na( classif[[1]])] 
  
  #extract
  for(i in sp$ids){ #id loop
    t = classif[[1]][names(classif[[1]]) == i][[1]]
    
    for(a in request){ #request loop
      
      if(length(t$name[t$rank == a]) >0) { #to avoid error. It is not possible to extract species from a family lvl record
        sp[sp$ids == i,colnames(sp) == a] = t$name[t$rank == a]
      }
    }#request loop
  } #id loop
  return(sp)
}


#extract
NCBI_verified = extract.classif(NCBI_uids,NCBI)
GBIF_verified = extract.classif(GBIF_uids,GBIF)

#merge
verified = rbind(NCBI_verified,GBIF_verified)
rm(NCBI_verified,GBIF_verified, GBIF_uids, NCBI_uids, NCBI, GBIF)

#clean
verified = verified %>% 
  select(c("user_provided_name","uri","species","genus","family","order","class"))
  

#For some reason, taxize Class is returning "NA" for Crocodylians and "Lepidosauria" for lizards (quick fix)
verified$class[verified$order %in% c("Squamata", "Crocodylia")] = "Reptilia"


### make the final Binomial_Verified column
  #if the taxa was not identified to the species level, than the most precise level is used

verified$binomial_verified = NA
verified$taxonomic_level = NA


for(i in 1:nrow(verified)){
  
  #Make a final verified_binomial column with the most precise taxonomic level found for each given taxa
  if(!is.na(verified$species[i])){
    verified$binomial_verified[i] = verified$species[i]
    verified$taxonomic_level[i] = "species"
    
    #Change species to remove the genus
    verified$species[i] = strsplit(verified$species[i], " ")[[1]][length(strsplit(verified$species[i], " ")[[1]])]
    
  }else if(!is.na(verified$genus[i])){
    verified$binomial_verified[i] = verified$genus[i]
    verified$taxonomic_level[i] = "genus"
  }else if(!is.na(verified$family[i])){
    verified$binomial_verified[i] = verified$family[i]
    verified$taxonomic_level[i] = "family"
  }else if(!is.na(verified$order[i])){
    verified$binomial_verified[i] = verified$order[i]
    verified$taxonomic_level[i] = "order"
  }
}; rm(i)


# There is corrected names! nice~
are_there_corrections = unique(captures$genus_species)[!unique(captures$genus_species) %in% verified$binomial_verified]

are_there_corrections = verified[verified$user_provided_name %in% are_there_corrections,]

rm(are_there_corrections)



###Apply the corrected names to the captures

captures = captures %>% 
  rename("user_provided_name" = genus_species) %>% 
  select(-c("Type","Family","Genus","species")) %>%
  left_join(verified, by = "user_provided_name") %>% 
  select(-"user_provided_name")


#Save the captures


write.csv(captures, "CamTrapAsia_Captures_20230825.csv", row.names = F)



### Add some bonus data for facilitate the life of the busy researchers which will use this dataset ~ (after all, life is like rapadura, sweet but hard!)

species_traits = verified %>%
  select(-"user_provided_name")
  
rm(verified)


#Load data from the COMBINE mammalian trait dataset

#COMBINE = read.csv("trait_data_imputed.csv") #This table is available at: https://doi.org/10.1002/ecy.3344

#Soria, C.D., Pacifici, M. Di Marco, M. Stephen, S.M., and C. Rondinini. 2021. COMBINE: a coalesced mammal database of intrinsic and extrinsic traits. Ecology 102 (6), e03344.

#An similar dataset for birds (not implemented here) is available at  https://doi.org/10.1111/ele.13898
#Tobias, J.A., Sheard, C., Pigot, A.L., Devenish, A.J.M., Yang, J., Sayol, F., et al. (2022) AVONET: morphological, ecological and geographical data for all birds. Ecology Letters, 25, 581– 597.



colnames(COMBINE)

#make space to save the trait data
species_traits$adult_mass_g = NA
species_traits$dphy_invertebrate = NA
species_traits$dphy_vertebrate = NA
species_traits$dphy_plant = NA
species_traits$det_diet_breadth_n = NA
species_traits$trophic_level = NA
species_traits$activity_cycle = NA
species_traits$habitat_breadth_n = NA
species_traits$iucn2020_binomial = NA #Some organizations use different classification systems. This column is useful to facilitate the access to the species IUCN status

for(i in 1:nrow(species_traits)){
  
  sp = species_traits$binomial_verified[i]
  
  #species
  if(sp %in% COMBINE$iucn2020_binomial | sp %in% COMBINE$phylacine_binomial){ #species loop
    
    t = COMBINE[COMBINE$iucn2020_binomial == sp | COMBINE$phylacine_binomial == sp,]
    
    if(nrow(t) > 1){t = t[t$iucn2020_binomial == sp,]} #In the case the two binomial columns disagree, use iucn2020_binomial first
    if(nrow(t) > 1){t = t[t$phylacine_binomial == sp,]} #In the case the two binomial columns disagree, use phylacine_binomial if the problem persists
    
    species_traits$adult_mass_g[i] = t$adult_mass_g
    species_traits$dphy_invertebrate[i] = t$dphy_invertebrate
    species_traits$dphy_vertebrate[i] = t$dphy_vertebrate
    species_traits$dphy_plant[i] = t$dphy_plant
    species_traits$det_diet_breadth_n[i] = t$det_diet_breadth_n
    species_traits$trophic_level[i] = t$trophic_level
    species_traits$activity_cycle[i] = t$activity_cycle
    species_traits$habitat_breadth_n[i] = t$habitat_breadth_n
    species_traits$iucn2020_binomial[i] = t$iucn2020_binomial
    
  } 
} ; rm(i,t,sp)



# Complete the iucn2020_binomial column (to facilitate searching in the IUCN database)
for(i in 1:nrow(species_traits)){
  if(is.na(species_traits$iucn2020_binomial[i])){
    species_traits$iucn2020_binomial[i] = species_traits$binomial_verified[i]
    }
}; rm(i)


#See the differences betweenbinomial_verified and iucn2020_binomial
compare = data.frame(
  "binomial_verified" = species_traits$binomial_verified[!species_traits$binomial_verified == species_traits$iucn2020_binomial],
  "iucn2020_binomial" = species_traits$iucn2020_binomial[!species_traits$binomial_verified == species_traits$iucn2020_binomial]
)

compare #mostly due to humans
rm(compare)



### obtain the IUCN status

#iucn_summary() require an IUCN API token in order to work # https://apiv3.iucnredlist.org/api/v3/token

#IUCN_list = iucn_summary(species_traits$iucn2020_binomial, distr_detail = F, key = "key_goes_here") #it will not work without the token! use ?iucn_summary() for help
  #note that this function sometimes stops printing the process status. It looks like it is stuck, but it still working...

species_traits$IUCN = iucn_status(IUCN_list)


#Save the species traits
write.csv(species_traits, "Species_traits_20230825.csv", row.names = F)


#save.image("Save2.Rdata")
#load("Save2.Rdata")




### Add some spatial metrics for the metadata

write.csv(metadata, "CamTrapAsia_Metadata_20230825.csv",  row.names = F)







